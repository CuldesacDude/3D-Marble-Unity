using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
  public float ballSpeed = 50f;

  private Rigidbody rig;

  private float HorizontalInput;

  private float VerticalInput;

  void Start(){

    rig = GetComponent<Rigidbody>();

  }

  void Update(){

    HorizontalInput = Input.GetAxis("Horizontal");

    VerticalInput = Input.GetAxis("Vertical");
      
  }

  private void FixedUpdate(){

    rig.AddForce(new Vector3(VerticalInput,0.0f,HorizontalInput ) * ballSpeed * Time.deltaTime);
  
  }

}
